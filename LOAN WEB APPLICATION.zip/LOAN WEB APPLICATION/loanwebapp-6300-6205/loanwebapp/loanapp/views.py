from django.shortcuts import render
#from django.http import HttpResponse
from .forms import applicationForm
from .models import applications

# Create your views here.

def home(request):
    return render(request, 'home.html')

def loanapplication(request):
    return render(request, 'loanapplication.html')

def applications(request):
    return render(request, 'applications.html')

def about(request):
    return render(request, 'about.html')

"""def loanapplication(request):
    applicants = applications.objects.all()
    totalapplicants = applications.objects.count()
    context = {'totalapplicants': totalapplicants}
    return render(request, 'loanapplication.html', context)"""

def applications(request):
    if request.method == 'POST':
        form = applicationForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'success.html')
    form = applicationForm()
    context = {'form': form}
    return render(request, 'applications.html',context)

