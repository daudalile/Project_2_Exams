from django.urls import path
from .import views

urlpatterns = [
    path('', views.home, name='home'),
    path('loanapplication', views.loanapplication, name='loanapplication'),
    path('applications', views.applications, name='applications'),
    path('about', views.about, name='about'),
]