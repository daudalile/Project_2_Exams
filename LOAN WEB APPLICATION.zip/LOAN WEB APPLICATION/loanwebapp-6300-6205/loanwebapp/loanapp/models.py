from django.db import models

# Create your models here.
#from django.db import models

class applications(models.Model):
    applicant_name = models.CharField(max_length=255, null='')
    email = models.EmailField(default='')
    phone_number = models.CharField(max_length=20, default='')
    amount_requested = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    employment_status = models.CharField(max_length=100, default='')
    address = models.CharField(max_length=255)
    city = models.CharField(max_length=100, default="")  
    date_applied = models.DateField()
    
    def __str__(self):
        return self.applicant_name